import { configureStore } from '@reduxjs/toolkit'
import  ComapreListReducer from './reducers/ComapreListReducerSlice'
export const store = configureStore({
  reducer: {
    ComapreListReducer
  },
})
