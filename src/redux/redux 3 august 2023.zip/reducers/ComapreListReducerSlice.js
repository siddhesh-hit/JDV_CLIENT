import { createSlice } from '@reduxjs/toolkit'

export const ComapreList = createSlice({
    name: 'ComapreList',
    initialState:{ComapreList:localStorage.getItem("comparelist")?JSON.parse(localStorage.getItem("comparelist")):[]},
    reducers: {
      AddToComapre: (state, action) => {
        const data=action.payload.data
        console.log({data})
        if(localStorage.getItem("comparelist")){
          let compareData= JSON.parse(localStorage.getItem("comparelist"))
          const existComapreList=compareData.find((item)=>data._id===item._id)
          if(existComapreList){
            // alert("already exist")
          return ;
          }else{
            state.ComapreList.push(data)
            localStorage.setItem('comparelist',JSON.stringify([...state.ComapreList]))
        
          }
      }else{
       
        state.ComapreList.push(data)
        localStorage.setItem('comparelist',JSON.stringify([...state.ComapreList]))
      }
      },
      DeleteFromComapre: (state, action) => {
        if(localStorage.getItem("comparelist")){
          let compareData= state.ComapreList
          const existComapreListindex=compareData.findIndex((item)=>action.payload.id===item._id)
          console.log("indexnumber",existComapreListindex)
            compareData.splice(existComapreListindex, 1)
             console.log("compareData Delete",compareData)
               console.log("save",state.ComapreList)
              localStorage.setItem('comparelist',JSON.stringify([...state.ComapreList]))
      }
      },
      DeleteAllFromComapre: (state) => {
        state.ComapreList = [];
        localStorage.removeItem('comparelist');
      },
    },
  })
  
  // Action creators are generated for each case reducer function
  export const { AddToComapre,DeleteFromComapre,DeleteAllFromComapre } = ComapreList.actions

  export default ComapreList.reducer
