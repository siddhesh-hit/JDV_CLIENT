import React, { useEffect } from "react";
import Header from "../Common/Header";
import Footer from "../Common/Footer";
import Travelbanner from "../Banner/Travelbanner";
import Insurancedetails from "../Common/Insurancedetails";
import { Form, InputGroup, ProgressBar } from "react-bootstrap";
import { Link } from "react-router-dom";
import { UseMotorContext } from "../../MultiStepContextApi";
const Traveldetails = () => {
  const { travelsFormsData, settravelsFormsData } = UseMotorContext();
  useEffect(() => {
    localStorage.setItem("travelsFormsDataLocation", window.location.pathname);
  }, []);
  const Progress = 20;
  return (
    <div>
      <Header />
      <Travelbanner />
      <div className="container-fluid car_info pt-4 pb-4">
        <div className="container">
          <ProgressBar now={Progress} label={`${Progress}%`} visuallyHidden />
          <div className="row" style={{ justifyContent: "center" }}>
            <div className="col-lg-12">
              <div className="row form_abcd">
                <h5>Insure your Travel in 2 minutes</h5>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default active">
                          <input type="radio" name="options" checked="" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                insure_your_travel: e.target.textContent,
                              }));
                            }}>Outbound</div>
                        </label>
                        <h6
                          style={{
                            marginBottom: "15px",
                            textAlign: "center",
                            fontSize: "16px",
                          }}
                        >
                          (UAE Residents Traveling From UAE)
                        </h6>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default">
                          <input type="radio" name="options" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                insure_your_travel: e.target.textContent,
                              }));
                            }}
                          >
                            Inbound
                          </div>
                        </label>
                        <h6
                          style={{
                            marginBottom: "15px",
                            textAlign: "center",
                            fontSize: "16px",
                          }}
                        >
                          (Travellers coming to UAE)
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <ul>
                    <li>Plan Type</li>
                  </ul>
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default">
                          <input type="radio" name="options" checked="" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                plan_type: e.target.textContent,
                              }));
                            }}>Single</div>
                        </label>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default active">
                          <input type="radio" name="options" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                plan_type: e.target.textContent,
                              }));
                            }}>Multiple trips / Annual </div>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <ul>
                    <li>No of Travel</li>
                  </ul>
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <InputGroup className="mb-4 mt-2">
                          <Form.Control
                            required
                            placeholder="No Of Travel"
                            value={travelsFormsData.no_of_travel}
                            aria-label="Full Name"
                            onChange={(e) => {
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  no_of_travel: e.target.value,
                                }));
                              }}
                          />
                        </InputGroup>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3">
                  <Link to="/" className="buttonactions">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>Back
                  </Link>
                </div>
                <div
                  className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3"
                  style={{ textAlign: "right" }}
                >
                  <Link to="/Traveldetailsform" className="buttonactions">
                    Next<i class="fa fa-chevron-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Insurancedetails />
      <Footer />
    </div>
  );
};

export default Traveldetails;
