import React from 'react'
import { Form } from 'react-bootstrap'
const Travelfilter = () => {
    return (
        <div className='col-lg-4 col-md-12 col-sm-12 col-xs-12 filters'>
            <p className='filtercheck'>Additional Filter</p>
            <Form.Check className='abcds_abcs filtercheck' type="checkbox" label="Rent a Car (Free)" />
            <Form.Check className='abcds_abcs filtercheck' type="checkbox" label="Oman Coverage (Free)" />
            <Form.Check className='abcds_abcs mb-3 filtercheck' type="checkbox" label="Passenger and Driver (Free)" />
            <h4 className='car details'>Travel Details<i className="fa fa-edit"></i></h4>
            <div className='filterssas one'>
                <div className='row'>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Travek Type</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Outbound</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Trip Period</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Single</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Number of Days</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>22 Days</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Start date</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>03-May-2023</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>End Date</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>24-May-2023</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Trip Type</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Family</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Destination</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Algeria</h6>
                    </div>
                </div>
            </div>
            <h4 className='personal details'>Personal Details<i className="fa fa-edit"></i></h4>
            <div className='filterssas two mb-5'>
                <div className='row'>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Name</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Hency Jadeja</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Email Address</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>henzala@gmail.com</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Mobile Number</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>+971 559593449</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Date of Birth</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>03-May-2023</h6>
                    </div>
                    <div className='col-lg-7 col-md-6 col-sm-6 col-xs-6'>
                        <h6>Passport Number</h6>
                    </div>
                    <div className='col-lg-5 col-md-6 col-sm-6 col-xs-6'>
                        <h6>6565665656</h6>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Travelfilter