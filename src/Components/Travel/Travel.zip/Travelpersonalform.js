import React, { useEffect } from "react";
import Header from "../Common/Header";
import Footer from "../Common/Footer";
import Travelbanner from "../Banner/Travelbanner";
import Insurancedetails from "../Common/Insurancedetails";
import { Link } from "react-router-dom";
import { Form, FormControl, InputGroup, ProgressBar } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useState } from "react";
import { UseMotorContext } from "../../MultiStepContextApi";
const Travelpersonalform = () => {
  const { travelsFormsData, settravelsFormsData } = UseMotorContext();
  const Progress = 40;
  useEffect(() => {
    localStorage.setItem("travelsFormsDataLocation", window.location.pathname);
  }, []);
  return (
    <div>
      <Header />
      <Travelbanner />
      <div className="container-fluid car_info pt-4 pb-4">
        <div className="container">
          <ProgressBar now={Progress} label={`${Progress}%`} visuallyHidden />
          <div className="row" style={{ justifyContent: "center" }}>
            <div className="col-lg-12">
              <div className="row form_abcd">
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <ul className="mb-3">
                    <li>Please fill your details :</li>
                  </ul>
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <InputGroup className="mb-4">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-user" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <Form.Control
                            required
                           
                            placeholder="Traveler Name"
                            aria-label="Traveler Name"
                            onChange={(e) =>
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  phone_no: e.target.value,
                                }))
                              }
                          />
                        </InputGroup>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <InputGroup className="mb-4">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <Form.Control
                            required
                            onChange={(e) =>
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  phone_no: e.target.value,
                                }))
                              }
                            placeholder="Phone Number"
                            aria-label="Phone Number"
                          />
                        </InputGroup>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <InputGroup className="mb-4">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <Form.Control
                              onChange={(e) =>
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  email: e.target.value,
                                }))
                              }
                            required
                            placeholder="Email ID"
                            aria-label="Email ID"
                          />
                        </InputGroup>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <InputGroup className="mb-4">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <DatePicker
                            placeholder="Email ID"
                            className="form-control"
                            selected={travelsFormsData.travel_start_date}
                            onChange={(date) =>
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  travel_start_date:date,
                                }))
                              }
                          />
                        </InputGroup>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <InputGroup className="mb-4">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <Form.Control
                            required
                            placeholder="Passport Number"
                            aria-label="Passport Number"
                            onChange={(e) =>
                                settravelsFormsData((prevData) => ({
                                  ...prevData,
                                  passport_no: e.target.value,
                                }))
                              }
                          />
                        </InputGroup>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3">
                  <Link to="/Traveldetailsform" className="buttonactions">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>Back
                  </Link>
                </div>
                <div
                  className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3"
                  style={{ textAlign: "right" }}
                >
                  <Link to="/Familydetails" className="buttonactions">
                    Next<i class="fa fa-chevron-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Insurancedetails />
      <Footer />
    </div>
  );
};

export default Travelpersonalform;
