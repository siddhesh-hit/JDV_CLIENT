import React, { useEffect } from "react";
import Header from "../Common/Header";
import Footer from "../Common/Footer";
import Travelbanner from "../Banner/Travelbanner";
import Insurancedetails from "../Common/Insurancedetails";
import { Link } from "react-router-dom";
import { Form, FormControl, InputGroup, ProgressBar } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useState } from "react";
import { UseMotorContext } from "../../MultiStepContextApi";
const Traveldetailsform = () => {
  const { travelsFormsData, settravelsFormsData } = UseMotorContext();
  useEffect(() => {
    localStorage.setItem("travelsFormsDataLocation", window.location.pathname);
  }, []);
  const Progress = 20;
  return (
    <div>
      <Header />
      <Travelbanner />
      <div className="container-fluid car_info pt-4 pb-4">
        <div className="container">
          <ProgressBar now={Progress} label={`${Progress}%`} visuallyHidden />
          <div className="row" style={{ justifyContent: "center" }}>
            <div className="col-lg-12">
              <div className="row form_abcd">
                <h5>Date Of Travel</h5>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <ul>
                          <li>Start Date</li>
                        </ul>
                        <InputGroup className="mb-5">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <DatePicker
                            placeholder="Email ID"
                            className="form-control"
                            selected={travelsFormsData.start_date}
                            onChange={(date) =>
                                settravelsFormsData((prevData) => ({
                                ...prevData,
                                start_date: date,
                              }))
                            }
                          />
                        </InputGroup>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <ul>
                          <li>End Date</li>
                        </ul>
                        <InputGroup className="mb-5">
                          <InputGroup.Text id="basic-addon1">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                          </InputGroup.Text>
                          <DatePicker
                            placeholder="Email ID"
                            className="form-control"
                            selected={travelsFormsData.end_date}
                            onChange={(date) =>
                                settravelsFormsData((prevData) => ({
                                ...prevData,
                                end_date: date,
                              }))
                            }
                          />
                        </InputGroup>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <ul>
                    <li>Type of trip</li>
                  </ul>
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default">
                          <input type="radio" name="options" checked="" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                type_of_trip: e.target.textContent,
                              }));
                            }}>Individual</div>
                        </label>
                      </div>
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 radiohide">
                        <label class="btn btn-default active">
                          <input type="radio" name="options" />
                          <div
                            onClick={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                type_of_trip: e.target.textContent,
                              }));
                            }}>Family</div>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-11 col-md-12 col-sm-12 col-xs-12">
                  <ul>
                    <li>Destination</li>
                  </ul>
                  <div class="button-group-pills" data-toggle="buttons">
                    <div className="row">
                      <div className="col-lg-6 col-md-6 col-sm-6 col-xs-12 mb-4">
                        <select onChange={(e) => {
                              settravelsFormsData((prevData) => ({
                                ...prevData,
                                travel_destination: e.target.value,
                              }));
                            }} className="form-control">
                          <option value={'India'}>India</option>
                          <option value={'UAE'}>UAE</option>
                          <option value={'China'}>China</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3">
                  <Link to="/Traveldetails" className="buttonactions">
                    <i class="fa fa-chevron-left" aria-hidden="true"></i>Back
                  </Link>
                </div>
                <div
                  className="col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3"
                  style={{ textAlign: "right" }}
                >
                  <Link to="/Travelpersonalform" className="buttonactions">
                    Next<i class="fa fa-chevron-right" aria-hidden="true"></i>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Insurancedetails />
      <Footer />
    </div>
  );
};

export default Traveldetailsform;
