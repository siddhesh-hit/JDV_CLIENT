import React, { useEffect, useState } from 'react'
import Header from '../Common/Header'
import Footer from '../Common/Footer'
import Travelbanner from '../Banner/Travelbanner'
import Insurancedetails from '../Common/Insurancedetails'
import { Link } from 'react-router-dom'
import { Form, FormControl, InputGroup, ProgressBar } from 'react-bootstrap'
import DatePicker from "react-datepicker"
import "react-datepicker/dist/react-datepicker.css"
import { UseMotorContext } from '../../MultiStepContextApi'

const Familydetails = () => {
    const {travelsFormsData, settravelsFormsData}=UseMotorContext()
    useEffect(()=>{
        localStorage.setItem('travelsFormsDataLocation',window.location.pathname)
     },[])
    const [startDate, setStartDate] = useState('');
    const Progress = 70;
    const [formValues, setFormValues] = useState([{ name: "", email: "", phone: "", date: "" }])

    let handleChange = (i, e) => {
        let date = new Date(e.target.value);
        let newFormValues = [...formValues];
        newFormValues[i][e.target.name] = e.target.value;
        setFormValues(newFormValues);
    }

    let addFormFields = () => {
        setFormValues([...formValues, { name: "", email: "", phone: "", date: "" }])
    }

    let removeFormFields = (i) => {
        let newFormValues = [...formValues];
        newFormValues.splice(i, 1);
        setFormValues(newFormValues)
    }

    let handleSubmit = (event) => {

        event.preventDefault();
        settravelsFormsData((prevData) => ({
            ...prevData,
            family_details:formValues,
          }))
        console.log("submit")
    }

    return (
        <div>
            <Header />
            <Travelbanner />
            <div className='container-fluid car_info pt-4 pb-4'>
                <div className='container'>
                    <ProgressBar now={Progress} label={`${Progress}%`} visuallyHidden />
                    <div className='row' style={{ justifyContent: 'center' }}>
                        <div className='col-lg-12 nopadding'>
                            <div className='row form_abcd'>
                                <div className='col-lg-11 col-md-12 col-sm-12 col-xs-12 mb-2'>
                                    <ul style={{ paddingLeft: '0px' }}>
                                        <li style={{ listStyle: 'none' }}>Please fill your family details :</li>
                                    </ul>
                                </div>
                                <form onSubmit={handleSubmit}>
                                    {formValues.map((element, index) => (
                                        <div className="row" key={index} style={{ justifyContent: 'space-around' }}>
                                            {
                                                index ?
                                                    <button type="button" className="button remove" onClick={() => removeFormFields(index)}>Remove</button>
                                                    : null
                                            }
                                            <div className='col-lg-5'>
                                                <InputGroup className="mb-4">
                                                    <InputGroup.Text id="basic-addon1"><i class="fa fa-user" aria-hidden="true"></i>
                                                    </InputGroup.Text>
                                                    <Form.Control name='name' defaultValue={element.name || ""} onChange={e => handleChange(index, e)} required
                                                        placeholder="Full Name"
                                                        aria-label="Full Name"
                                                    />
                                                </InputGroup>
                                            </div>
                                            <div className='col-lg-5'>
                                                <InputGroup className="mb-4">
                                                    <InputGroup.Text id="basic-addon1"><i class="fa fa-envelope-o" aria-hidden="true"></i></InputGroup.Text>
                                                    <Form.Control name='email' defaultValue={element.email || ""} onChange={e => handleChange(index, e)} required
                                                        placeholder="Email ID"
                                                        aria-label="Email ID"
                                                    />
                                                </InputGroup>
                                            </div>
                                            <div className='col-lg-5'>
                                                <InputGroup className="mb-4">
                                                    <InputGroup.Text id="basic-addon1"><i class="fa fa-phone" aria-hidden="true"></i>
                                                    </InputGroup.Text>
                                                    <Form.Control required name='phone' defaultValue={element.phone || ""} onChange={e => handleChange(index, e)}
                                                        placeholder="Phone Number"
                                                        aria-label="Phone Number"
                                                    />
                                                </InputGroup>
                                            </div>
                                            <div className='col-lg-5'>
                                                <InputGroup className="mb-4">
                                                    <InputGroup.Text id="basic-addon1"><i class="fa fa-calendar" aria-hidden="true"></i></InputGroup.Text>
                                                    <DatePicker selected={startDate} onChange={setStartDate} name='date' placeholderText={'Please select a date'} className='form-control' />
                                                </InputGroup>
                                            </div>
                                        </div>
                                    ))}
                                    <div className="button-section1">
                                        <button className="button add" type="button" onClick={() => addFormFields()}>Add</button>
                                        <button className="button submit" type="submit">Submit</button>
                                    </div>
                                </form>
                                <div className='col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3'>
                                    <Link to="/Travelpersonalform" className='buttonactions'><i class="fa fa-chevron-left" aria-hidden="true"></i>Back</Link>
                                </div>
                                <div className='col-lg-5 col-md-12 col-sm-12 col-xs-12 buttons mt-3 mb-3' style={{ textAlign: 'right' }}>
                                    <Link to="/Beneficarydetails" className='buttonactions'>Next<i class="fa fa-chevron-right" aria-hidden="true"></i></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Insurancedetails />
            <Footer />
        </div>
    )
}

export default Familydetails